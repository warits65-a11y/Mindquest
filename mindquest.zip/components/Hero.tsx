import React from 'react';
import { ArrowRight, PlayCircle } from 'lucide-react';
import { ViewState } from '../types';

interface HeroProps {
  onNavigate: (view: ViewState) => void;
}

const OwlLogo = () => (
  <svg viewBox="0 0 200 200" className="w-full h-full">
    <defs>
      <linearGradient id="logoBg" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#3730a3" /> {/* Indigo-800 */}
        <stop offset="100%" stopColor="#1e1b4b" /> {/* Indigo-950 */}
      </linearGradient>
      <linearGradient id="wingGradient" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stopColor="#60a5fa" /> {/* Blue-400 */}
        <stop offset="100%" stopColor="#3b82f6" /> {/* Blue-500 */}
      </linearGradient>
    </defs>
    
    {/* Background Circle */}
    <circle cx="100" cy="100" r="100" fill="url(#logoBg)" />
    
    {/* Wings / Body Container */}
    <g transform="translate(0, 10)">
       <path d="M30 70 Q 10 50 50 60 Q 90 80 100 110 Q 110 80 150 60 Q 190 50 170 70 L 170 120 Q 170 160 100 175 Q 30 160 30 120 Z" fill="#818cf8" />
       
       {/* Inner Body Shield */}
       <path d="M50 70 Q 50 50 100 50 Q 150 50 150 70 L 140 140 Q 100 170 60 140 Z" fill="url(#wingGradient)" opacity="0.9" />
       
       {/* Chest Heart */}
       <path d="M100 115 C 100 115 80 100 80 125 C 80 140 100 155 100 155 C 100 155 120 140 120 125 C 120 100 100 115 100 115" fill="#c084fc" />
       
       {/* Eyes */}
       <circle cx="75" cy="85" r="22" fill="#e0e7ff" />
       <circle cx="125" cy="85" r="22" fill="#e0e7ff" />
       
       {/* Pupils */}
       <circle cx="75" cy="85" r="9" fill="#1e1b4b" />
       <circle cx="125" cy="85" r="9" fill="#1e1b4b" />
       
       {/* Beak */}
       <path d="M92 105 L 100 118 L 108 105" fill="#facc15" />
    </g>
  </svg>
);

const Hero: React.FC<HeroProps> = ({ onNavigate }) => {
  return (
    <div className="relative min-h-screen text-white overflow-hidden flex flex-col items-center justify-center">
      {/* Immersive Forest Background - Static */}
      <div className="absolute inset-0 z-0">
        <img 
            src="https://images.unsplash.com/photo-1441974231531-c6227db76b6e?q=80&w=2000&auto=format&fit=crop" 
            alt="Mystical Forest" 
            className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-indigo-900/70 via-indigo-900/50 to-black/80"></div>
      </div>

      <nav className="absolute top-0 w-full p-6 flex justify-between items-center z-20">
        <div className="text-2xl font-bold flex items-center gap-3 drop-shadow-lg">
           <div className="w-14 h-14 rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(99,102,241,0.6)] border-2 border-white/20">
             <OwlLogo />
           </div>
           <div className="flex flex-col">
             <span className="font-serif tracking-wide text-2xl leading-none">MindQuest</span>
             <span className="text-[10px] font-light text-mq-soft-purple uppercase tracking-widest opacity-80">Know Your Mind</span>
           </div>
        </div>
        <div className="hidden md:flex gap-6 text-sm font-semibold text-gray-200">
          <button onClick={() => onNavigate('alex-story')} className="hover:text-mq-yellow transition drop-shadow-md">The Wolf's Tale</button>
          <button onClick={() => onNavigate('stats')} className="hover:text-mq-yellow transition drop-shadow-md">Forest Records</button>
          <button onClick={() => onNavigate('help')} className="hover:text-mq-yellow transition drop-shadow-md">Healer's Hut</button>
        </div>
      </nav>

      <div className="container mx-auto px-6 z-20 text-center flex flex-col items-center">
        <div className="mb-8 relative group cursor-pointer" onClick={() => onNavigate('assessment')}>
           {/* Animated Spirit Animal Glow */}
           <div className="absolute inset-0 bg-indigo-500 rounded-full opacity-20 blur-xl group-hover:opacity-40 transition-opacity duration-1000 animate-pulse"></div>
           <div className="w-48 h-48 md:w-56 md:h-56 rounded-full p-1 mx-auto relative overflow-hidden border-4 border-white/30 backdrop-blur-sm shadow-2xl transition transform group-hover:scale-105">
             <img 
               src="https://images.unsplash.com/photo-1579370966779-37332e18538b?q=80&w=1000&auto=format&fit=crop" 
               alt="Spirit Guide Owl" 
               className="w-full h-full object-cover rounded-full"
             />
           </div>
           <div className="absolute -bottom-2 w-full text-center">
             <span className="bg-indigo-900/80 text-mq-yellow px-4 py-1 rounded-full text-xs font-bold shadow-lg backdrop-blur-md border border-white/10 uppercase tracking-widest">
               Your Spirit Guide
             </span>
           </div>
        </div>

        <h1 className="text-5xl md:text-7xl font-extrabold mb-4 tracking-tight font-serif drop-shadow-2xl">
          Discover Your <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-mq-yellow to-orange-400">Spirit Animal</span>
        </h1>
        
        <p className="text-xl md:text-2xl font-light text-gray-200 mb-10 max-w-xl mx-auto leading-relaxed drop-shadow-md">
          Journey through the Forest of Minds. <br/>
          Uncover the hidden strengths and silent shadows within you.
        </p>

        <div className="flex flex-col md:flex-row gap-5">
          <button 
            onClick={() => onNavigate('assessment')}
            className="group bg-mq-yellow text-mq-dark px-10 py-4 rounded-full font-bold text-lg hover:bg-white transition-all transform hover:scale-105 shadow-[0_0_20px_rgba(250,204,21,0.4)] flex items-center gap-3"
          >
            <PlayCircle className="w-6 h-6" />
            Begin the Ritual
          </button>
          
          <button 
            onClick={() => onNavigate('alex-story')}
            className="px-8 py-4 rounded-full font-semibold text-white border border-white/30 hover:bg-white/10 backdrop-blur-md transition-all flex items-center gap-2"
          >
            Read the Legend <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="absolute bottom-6 text-xs text-gray-400 opacity-60">
        AI Generated Experience • Guided by Professionals
      </div>
    </div>
  );
};

export default Hero;