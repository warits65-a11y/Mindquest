import React, { useState, useEffect } from 'react';
import { Play, Pause, SkipForward, Volume2 } from 'lucide-react';
import { STORY_SCENES } from '../constants';
import { AssessmentResult } from '../types';

interface AssessmentProps {
  onComplete: (result: AssessmentResult) => void;
}

const Assessment: React.FC<AssessmentProps> = ({ onComplete }) => {
  const [currentSceneIndex, setCurrentSceneIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [showOptions, setShowOptions] = useState(false);
  
  // Scoring state
  const [phq2Score, setPhq2Score] = useState(0);
  const [phq9Score, setPhq9Score] = useState(0);
  const [suicideScore, setSuicideScore] = useState(0);

  const [progress, setProgress] = useState(0);

  const currentScene = STORY_SCENES[currentSceneIndex];

  // Logic to find indices
  const q9StartIndex = STORY_SCENES.findIndex(s => s.section === '9Q');
  const q8StartIndex = STORY_SCENES.findIndex(s => s.section === '8Q');

  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    if (isPlaying) {
      interval = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 100) {
            setIsPlaying(false);
            setShowOptions(true);
            return 100;
          }
          return prev + 4; // Fast progression
        });
      }, 30);
    }
    return () => clearInterval(interval);
  }, [isPlaying]);

  const handleStartScene = () => {
    setIsPlaying(true);
    setProgress(0);
    setShowOptions(false);
  };

  const handleOptionSelect = (score: number) => {
    let newP2 = phq2Score;
    let newP9 = phq9Score;
    let newS8 = suicideScore;

    if (currentScene.section === '2Q') newP2 += score;
    if (currentScene.section === '9Q') newP9 += score;
    if (currentScene.section === '8Q') newS8 += score;

    setPhq2Score(newP2);
    setPhq9Score(newP9);
    setSuicideScore(newS8);

    const isLastIn2Q = currentScene.id === 2;
    const isLastIn9Q = currentScene.id === 9; // Based on 9Q having 7 items starting from ID 3
    const isLastIn8Q = currentSceneIndex === STORY_SCENES.length - 1;

    // Check branching logic
    if (isLastIn2Q) {
      if (newP2 > 0) {
        // Proceed to 9Q
        moveToScene(q9StartIndex);
      } else {
        // Normal - Stop here
        finishAssessment(newP2, newP9, newS8);
      }
    } else if (isLastIn9Q) {
      if (newP9 >= 7) {
        // Proceed to 8Q
        moveToScene(q8StartIndex);
      } else {
        // Stop here
        finishAssessment(newP2, newP9, newS8);
      }
    } else if (isLastIn8Q) {
      finishAssessment(newP2, newP9, newS8);
    } else {
      // Just move to the next question in the sequence
      moveToScene(currentSceneIndex + 1);
    }
  };

  const moveToScene = (index: number) => {
    setCurrentSceneIndex(index);
    setProgress(0);
    setShowOptions(false);
    setIsPlaying(false);
  };

  const finishAssessment = (p2: number, p9: number, s8: number) => {
    let persona: AssessmentResult['persona'] = 'Lion';
    let riskLevel: AssessmentResult['riskLevel'] = 'Low';
    let desc = "You possess the heart of a Lion. You are resilient, strong, and in control of your journey.";
    let rec = "Keep leading your pride with confidence. Maintain your balance.";

    if (s8 >= 17) {
        persona = 'Wolf';
        riskLevel = 'High';
        desc = "The Lone Wolf in the Arctic. The shadows have grown cold, and the path ahead feels dangerous.";
        rec = "URGENT: Your safety is the priority. Please reach out to a professional mental health specialist immediately.";
    } else if (p9 >= 13 || s8 >= 9) {
        persona = 'Owl';
        riskLevel = 'Moderate';
        desc = "The Watchful Owl. You navigate the night with wisdom, but the darkness is starting to blur your vision.";
        rec = "It is brave to speak up. Consider talking to a counselor or someone you trust about your feelings.";
    } else if (p9 >= 7 || s8 >= 1) {
        persona = 'Dolphin';
        riskLevel = 'Moderate';
        desc = "The Drifting Dolphin. You are agile and kind, but the currents are pulling you deeper than you'd like.";
        rec = "Don't swim alone. Sharing your story with a friend or specialist can lighten the load.";
    }

    onComplete({
        score: p9,
        phq2Score: p2,
        phq9Score: p9,
        suicideScore: s8,
        persona,
        riskLevel,
        description: desc,
        recommendation: rec
    });
  };

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center p-4">
      <style>
        {`
          @keyframes ken-burns {
            0% { transform: scale(1); }
            100% { transform: scale(1.15); }
          }
          .animate-ken-burns {
            animation: ken-burns 10s ease-out forwards;
          }
        `}
      </style>
      <div className="w-full max-w-4xl aspect-video bg-gray-900 rounded-2xl overflow-hidden relative shadow-2xl border border-gray-800">
        <div className="absolute inset-0 overflow-hidden">
           <img 
             src={currentScene.videoPlaceholderUrl} 
             alt="Scene" 
             className={`w-full h-full object-cover transition-all duration-1000 
               ${showOptions ? 'opacity-30 blur-sm scale-110' : 'opacity-80'}
               ${isPlaying ? 'animate-ken-burns' : ''}
             `}
           />
           <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"></div>
        </div>

        {!isPlaying && !showOptions && progress === 0 && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/40 z-20 backdrop-blur-sm">
             <button onClick={handleStartScene} className="group flex flex-col items-center gap-4 transition">
                <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-md group-hover:scale-110 transition border border-white/40">
                  <Play className="w-10 h-10 text-white fill-white ml-1" />
                </div>
                <span className="text-white text-xl font-bold tracking-widest uppercase font-serif">Continue Expedition: {currentScene.title}</span>
             </button>
          </div>
        )}

        {(isPlaying || showOptions) && (
            <div className="absolute bottom-0 w-full p-6 z-20 text-white">
                <div className="flex justify-between items-center mb-2">
                   <h3 className="text-2xl font-bold font-serif">{currentScene.title}</h3>
                   <span className="text-xs bg-white/20 px-2 py-1 rounded border border-white/20 uppercase tracking-widest">Adventure Check: {currentScene.section}</span>
                </div>
                <p className="text-lg opacity-90 mb-4 font-light italic">"{currentScene.description}"</p>
                <div className="w-full h-1 bg-gray-700 rounded-full mb-4 overflow-hidden">
                    <div className="h-full bg-mq-yellow transition-all duration-75 ease-linear" style={{ width: `${progress}%` }}></div>
                </div>
            </div>
        )}

        {showOptions && (
            <div className="absolute inset-0 flex flex-col items-center justify-center z-30 p-8 animate-fade-in">
                <h2 className="text-3xl font-bold text-white mb-8 text-center drop-shadow-lg font-serif">{currentScene.question}</h2>
                <div className="grid gap-4 w-full max-w-lg">
                    {currentScene.options.map((opt, idx) => (
                        <button
                            key={idx}
                            onClick={() => handleOptionSelect(opt.score)}
                            className="bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/30 text-white p-4 rounded-xl text-left transition transform hover:scale-102 flex justify-between items-center group"
                        >
                            <span className="font-medium text-lg">{opt.label}</span>
                            <div className="w-6 h-6 rounded-full border-2 border-white/50 group-hover:bg-mq-yellow group-hover:border-mq-yellow transition"></div>
                        </button>
                    ))}
                </div>
            </div>
        )}
      </div>

      <div className="mt-8 flex gap-4 text-gray-400 text-sm">
         <span className="font-bold text-white">Section: {currentScene.section}</span>
         <span className="opacity-50">|</span>
         <span className="text-mq-yellow">Expedition in progress...</span>
      </div>
    </div>
  );
};

export default Assessment;