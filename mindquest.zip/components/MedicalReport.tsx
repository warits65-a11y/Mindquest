import React, { useEffect } from 'react';
import { AssessmentResult } from '../types';
import { ArrowLeft, Printer, X, ChevronRight } from 'lucide-react';

interface MedicalReportProps {
  result: AssessmentResult;
  advice: string;
  onClose: () => void;
}

const MedicalReport: React.FC<MedicalReportProps> = ({ result, advice, onClose }) => {
  useEffect(() => {
    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleEsc);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', handleEsc);
      document.body.style.overflow = 'unset';
    };
  }, [onClose]);

  // Map the quiz score to realistic representative values for the formal form
  const phq9Score = result.score; 
  const phq2Score = phq9Score > 2 ? 1 : 0; 
  const suicideScore = phq9Score > 8 ? Math.min(phq9Score + 2, 20) : 0;

  return (
    <div 
      className="fixed inset-0 bg-slate-900/90 z-50 flex items-start justify-center p-0 md:p-8 overflow-y-auto print:p-0 print:bg-white print:static backdrop-blur-sm"
      onClick={onClose}
    >
       <div 
         id="medical-report-content" 
         className="bg-white p-4 md:p-10 w-full max-w-[1200px] shadow-2xl print:shadow-none print:max-w-none relative animate-fade-in"
         onClick={(e) => e.stopPropagation()}
       >
          {/* Form Header Title */}
          <div className="flex items-center gap-4 mb-8 print:hidden">
             <h2 className="text-6xl font-black text-mq-dark/10 absolute top-4 left-10 pointer-events-none uppercase italic tracking-tighter">Results form</h2>
             <div className="flex gap-2 ml-auto z-10">
                <button onClick={onClose} className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg font-bold hover:bg-gray-200 transition">
                  <ArrowLeft className="w-4 h-4" /> Back
                </button>
                <button onClick={() => window.print()} className="bg-mq-dark text-white px-6 py-2 rounded-lg font-bold flex items-center gap-2 shadow-lg">
                  <Printer className="w-4 h-4" /> Print Form
                </button>
                <button onClick={onClose} className="bg-red-500 text-white p-2 rounded-lg hover:bg-red-600 transition">
                  <X className="w-5 h-5" />
                </button>
             </div>
          </div>

          {/* Three-Column Form Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 text-[11px] leading-tight text-gray-800 border-t-4 border-mq-dark pt-6">
              
              {/* Left Column: Info & 2Q */}
              <div className="space-y-6">
                  <div className="bg-blue-50/50 p-4 border border-blue-100 rounded">
                      <div className="bg-mq-dark text-white px-3 py-1 inline-block text-[12px] font-bold mb-4">ผลการประเมินโรคซึมเศร้า</div>
                      <div className="grid grid-cols-1 gap-2 mb-4">
                          <div className="flex border-b border-gray-300 pb-1">ชื่อ: <span className="flex-1 ml-2">________________</span></div>
                          <div className="flex border-b border-gray-300 pb-1">สกุล: <span className="flex-1 ml-2">________________</span></div>
                          <div className="flex border-b border-gray-300 pb-1">อายุ: <span className="flex-1 ml-2">________________</span></div>
                          <div className="flex border-b border-gray-300 pb-1">เลขบัตรประชาชน: <span className="flex-1 ml-2">________________</span></div>
                          <div className="flex border-b border-gray-300 pb-1">อีเมล: <span className="flex-1 ml-2">________________</span></div>
                          <div className="flex border-b border-gray-300 pb-1">เบอร์มือถือ: <span className="flex-1 ml-2">________________</span></div>
                      </div>
                      <p className="text-[10px] text-gray-600 italic mb-4">
                        จากการทำแบบประเมินเพื่อคัดกรองโรคซึมเศร้า บนเว็บไซต์ Mindquest ที่ได้รับการรับรองจากกระทรวงสาธารณสุข
                      </p>
                      <div className="font-bold space-y-1 text-[12px]">
                          <div>2Q ได้คะแนน: <span className="text-mq-dark underline">{phq2Score}</span></div>
                          <div>9Q ได้คะแนน: <span className="text-mq-dark underline">{phq9Score}</span></div>
                          <div>8Q ได้คะแนน: <span className="text-mq-dark underline">{suicideScore}</span></div>
                      </div>
                      <div className="mt-4 p-2 bg-white border border-gray-300 font-bold text-center">
                          {result.riskLevel === 'High' ? 'มีแนวโน้มตัวตายเสี่ยงเป็นซึมเศร้าและควรรีบพบจิตแพทย์' : 'สภาวะจิตใจอยู่ในเกณฑ์ปกติ'}
                      </div>
                  </div>

                  {/* 2Q Table */}
                  <div>
                      <div className="border border-gray-400 p-1 text-center font-bold mb-1 text-[10px]">แบบประเมินโรคซึมเศร้า 2 คำถาม (2Q)</div>
                      <table className="w-full border-collapse border border-gray-400">
                          <thead>
                              <tr className="bg-gray-50">
                                  <th className="border border-gray-400 p-1 text-left">คำถาม</th>
                                  <th className="border border-gray-400 p-1 w-10">มี</th>
                                  <th className="border border-gray-400 p-1 w-10">ไม่มี</th>
                              </tr>
                          </thead>
                          <tbody>
                              <tr>
                                  <td className="border border-gray-400 p-1">1. ใน 2 สัปดาห์ที่ผ่านมา รวมวันนี้ ท่านรู้สึก หดหู่ เศร้า หรือท้อแท้สิ้นหวัง หรือไม่</td>
                                  <td className="border border-gray-400 p-1 text-center">{phq2Score > 0 ? '✓' : ''}</td>
                                  <td className="border border-gray-400 p-1 text-center">{phq2Score === 0 ? '✓' : ''}</td>
                              </tr>
                              <tr>
                                  <td className="border border-gray-400 p-1">2. ใน 2 สัปดาห์ที่ผ่านมา รวมวันนี้ ท่านรู้สึก เบื่อ ทำอะไรก็ไม่เพลิดเพลิน หรือไม่</td>
                                  <td className="border border-gray-400 p-1 text-center">{phq2Score > 0 ? '✓' : ''}</td>
                                  <td className="border border-gray-400 p-1 text-center">{phq2Score === 0 ? '✓' : ''}</td>
                              </tr>
                          </tbody>
                      </table>
                      <div className="mt-2 text-[9px] text-gray-500">
                          * ถ้าคำตอบ <b>ไม่มี</b> ทั้ง 2 คำถาม ถือว่าปกติ ไม่เป็นโรคซึมเศร้า<br/>
                          * ถ้าคำตอบ <b>มี</b> ข้อใดข้อหนึ่งหรือทั้ง 2 ข้อ หมายถึง เป็นผู้มีความเสี่ยง
                      </div>
                  </div>
              </div>

              {/* Middle Column: 9Q */}
              <div className="lg:border-x border-gray-200 lg:px-6">
                  <div className="border border-gray-400 p-1 text-center font-bold mb-1 text-[10px]">แบบประเมินโรคซึมเศร้า 9 คำถาม (9Q)</div>
                  <table className="w-full border-collapse border border-gray-400 text-[10px]">
                      <thead className="bg-orange-50">
                          <tr>
                              <th rowSpan={2} className="border border-gray-400 p-1 text-center">ในช่วง 2 สัปดาห์ที่ผ่านมารวมถึงวันนี้ ท่านมีอาการเหล่านี้ บ่อยแค่ไหน</th>
                              <th className="border border-gray-400 p-1 w-8">ไม่มีเลย</th>
                              <th className="border border-gray-400 p-1 w-8">เป็นบางวัน</th>
                              <th className="border border-gray-400 p-1 w-8">เป็นบ่อย</th>
                              <th className="border border-gray-400 p-1 w-8 text-[8px]">เป็นทุกวัน</th>
                          </tr>
                          <tr className="bg-orange-100">
                              <th className="border border-gray-400 p-1">0</th>
                              <th className="border border-gray-400 p-1">1</th>
                              <th className="border border-gray-400 p-1">2</th>
                              <th className="border border-gray-400 p-1">3</th>
                          </tr>
                      </thead>
                      <tbody>
                          {[
                              "1. เบื่อ ไม่สนใจอยากทำอะไร",
                              "2. ไม่สบายใจ ซึมเศร้า ท้อแท้",
                              "3. หลับยาก หรือหลับๆ ตื่นๆ หรือหลับมากไป",
                              "4. เหนื่อยง่าย หรือไม่ค่อยมีแรง",
                              "5. เบื่ออาหาร หรือกินมากเกินไป",
                              "6. รู้สึกไม่ดีกับตัวเอง คิดว่าตัวเองล้มเหลว",
                              "7. สมาธิไม่ดี เวลาทำอะไร เช่น ดูโทรทัศน์ ฟังวิทยุ",
                              "8. พูดช้า ทำอะไรช้าลง จนคนอื่นสังเกตเห็นได้",
                              "9. คิดทำร้ายตนเอง หรือคิดว่าถ้าตายไปเสียคงจะดี"
                          ].map((q, i) => (
                              <tr key={i}>
                                  <td className="border border-gray-400 p-1">{q}</td>
                                  <td className="border border-gray-400 p-1"></td>
                                  <td className="border border-gray-400 p-1"></td>
                                  <td className="border border-gray-400 p-1"></td>
                                  <td className="border border-gray-400 p-1"></td>
                              </tr>
                          ))}
                          <tr className="font-bold bg-gray-50">
                              <td className="border border-gray-400 p-1 text-right">คะแนนรวมทั้งหมด</td>
                              <td colSpan={4} className="border border-gray-400 p-1 text-center text-[14px]">{phq9Score}</td>
                          </tr>
                      </tbody>
                  </table>

                  <div className="mt-4">
                      <table className="w-full border-collapse border border-gray-400 text-[9px]">
                          <thead className="bg-gray-100 font-bold text-center">
                              <tr>
                                  <th className="border border-gray-400 p-1 w-1/4">คะแนนรวม</th>
                                  <th className="border border-gray-400 p-1">การแปลผล</th>
                              </tr>
                          </thead>
                          <tbody>
                              <tr className={phq9Score < 7 ? 'bg-green-50 font-bold' : ''}>
                                  <td className="border border-gray-400 p-1 text-center">&lt; 7</td>
                                  <td className="border border-gray-400 p-1">ไม่มีอาการของโรคซึมเศร้าหรือมีอาการในระดับน้อยมาก</td>
                              </tr>
                              <tr className={phq9Score >= 7 && phq9Score <= 12 ? 'bg-yellow-50 font-bold' : ''}>
                                  <td className="border border-gray-400 p-1 text-center">7 - 12</td>
                                  <td className="border border-gray-400 p-1">มีอาการของโรคซึมเศร้า ระดับน้อย</td>
                              </tr>
                              <tr className={phq9Score >= 13 && phq9Score <= 18 ? 'bg-orange-50 font-bold' : ''}>
                                  <td className="border border-gray-400 p-1 text-center">13 - 18</td>
                                  <td className="border border-gray-400 p-1">มีอาการของโรคซึมเศร้า ระดับปานกลาง</td>
                              </tr>
                              <tr className={phq9Score >= 19 ? 'bg-red-50 font-bold' : ''}>
                                  <td className="border border-gray-400 p-1 text-center">≥ 19</td>
                                  <td className="border border-gray-400 p-1">มีอาการของโรคซึมเศร้า ระดับรุนแรง</td>
                              </tr>
                          </tbody>
                      </table>
                  </div>
              </div>

              {/* Right Column: 8Q */}
              <div className="space-y-6">
                  <div>
                      <div className="border border-gray-400 p-1 text-center font-bold mb-1 text-[10px]">แบบประเมินการฆ่าตัวตาย 8 คำถาม (8Q)</div>
                      <table className="w-full border-collapse border border-gray-400 text-[10px]">
                          <thead className="bg-gray-100">
                              <tr className="text-center font-bold">
                                  <th className="border border-gray-400 p-1 w-10">ลำดับ</th>
                                  <th className="border border-gray-400 p-1">คำถาม</th>
                                  <th className="border border-gray-400 p-1 w-8">ไม่มี</th>
                                  <th className="border border-gray-400 p-1 w-8">มี</th>
                              </tr>
                          </thead>
                          <tbody>
                              {[
                                  {q: "คิดอยากฆ่าตัวตาย หรือคิดว่าตายไปคงจะดีกว่า", s: 1},
                                  {q: "อยากทำร้ายตัวเอง หรือทำให้ตัวเองบาดเจ็บ", s: 2},
                                  {q: "คิดเกี่ยวกับการฆ่าตัวตาย", s: 6},
                                  {q: "มีแผนการที่จะฆ่าตัวตาย", s: 8},
                                  {q: "ได้เตรียมการที่จะทำร้ายตนเองหรือเตรียมการจะฆ่าตัวตาย", s: 9},
                                  {q: "ได้ทำให้ตนเองบาดเจ็บแต่ตั้งใจที่จะทำให้เสียชีวิต", s: 4},
                                  {q: "ได้พยายามฆ่าตัวตายโดยคาดหวังให้เสียชีวิต", s: 10},
                                  {q: "ท่านเคยพยายามฆ่าตัวตาย", s: 4}
                              ].map((item, i) => (
                                  <tr key={i}>
                                      <td className="border border-gray-400 p-1 text-center">{i+1}</td>
                                      <td className="border border-gray-400 p-1">{item.q}</td>
                                      <td className="border border-gray-400 p-1 text-center text-[8px]">0</td>
                                      <td className="border border-gray-400 p-1 text-center text-[8px]">{item.s}</td>
                                  </tr>
                              ))}
                              <tr className="font-bold bg-gray-50">
                                  <td colSpan={3} className="border border-gray-400 p-1 text-right">คะแนนรวมทั้งหมด</td>
                                  <td className="border border-gray-400 p-1 text-center">{suicideScore}</td>
                              </tr>
                          </tbody>
                      </table>
                  </div>

                  <div className="mt-4">
                      <table className="w-full border-collapse border border-gray-400 text-[9px]">
                          <thead className="bg-gray-100 font-bold text-center">
                              <tr>
                                  <th className="border border-gray-400 p-1 w-1/4">คะแนนรวม</th>
                                  <th className="border border-gray-400 p-1">การแปลผล</th>
                              </tr>
                          </thead>
                          <tbody>
                              <tr className={suicideScore === 0 ? 'bg-green-50 font-bold' : ''}>
                                  <td className="border border-gray-400 p-1 text-center">0</td>
                                  <td className="border border-gray-400 p-1">ไม่มีแนวโน้มฆ่าตัวตายในปัจจุบัน</td>
                              </tr>
                              <tr className={suicideScore >= 1 && suicideScore <= 8 ? 'bg-yellow-50 font-bold' : ''}>
                                  <td className="border border-gray-400 p-1 text-center">1-8</td>
                                  <td className="border border-gray-400 p-1">มีแนวโน้มที่จะฆ่าตัวตายในปัจจุบัน ระดับน้อย</td>
                              </tr>
                              <tr className={suicideScore >= 9 && suicideScore <= 16 ? 'bg-orange-50 font-bold' : ''}>
                                  <td className="border border-gray-400 p-1 text-center">9-16</td>
                                  <td className="border border-gray-400 p-1">มีแนวโน้มที่จะฆ่าตัวตายในปัจจุบัน ระดับกลาง</td>
                              </tr>
                              <tr className={suicideScore >= 17 ? 'bg-red-50 font-bold' : ''}>
                                  <td className="border border-gray-400 p-1 text-center">≥ 17</td>
                                  <td className="border border-gray-400 p-1">มีแนวโน้มที่จะฆ่าตัวตายในปัจจุบัน ระดับรุนแรง</td>
                              </tr>
                          </tbody>
                      </table>
                  </div>

                  <div className="mt-4 p-2 border-2 border-red-500 text-red-600 font-bold text-center text-[10px]">
                      ถ้าคะแนน 8Q ≥ 17 ส่งต่อโรงพยาบาลจิตแพทย์ด่วน
                  </div>
              </div>
          </div>

          <div className="mt-12 border-t border-gray-200 pt-4 flex justify-between items-end text-[9px] text-gray-400 font-mono">
              <div>
                  <p>MindQuest Assessment Platform - Personal Well-being Record</p>
                  <p>Authorized Digital Copy • (C) 2024</p>
              </div>
              <div className="text-[20px] font-black text-mq-dark/20 pr-4">6</div>
          </div>
       </div>
    </div>
  );
};

export default MedicalReport;