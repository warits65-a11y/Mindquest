import React from 'react';
import { ArrowLeft, ArrowRight, Moon } from 'lucide-react';
import { ViewState } from '../types';

interface AlexStoryProps {
  onBack: () => void;
  onNext: () => void;
}

const AlexStory: React.FC<AlexStoryProps> = ({ onBack, onNext }) => {
  return (
    <div className="min-h-screen bg-[#0f172a] text-slate-200 p-6 md:p-12 font-serif">
      <button onClick={onBack} className="flex items-center gap-2 text-gray-400 font-sans font-bold mb-8 hover:text-white transition">
        <ArrowLeft className="w-5 h-5" /> Return to Forest
      </button>

      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-12">
            <h2 className="text-4xl md:text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-200 to-indigo-400 mb-4">
            The Tale of the Silent Wolf
            </h2>
            <p className="text-xl text-blue-200 italic">A story about the masks we wear.</p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="relative rounded-t-full rounded-b-2xl overflow-hidden shadow-[0_0_40px_rgba(30,58,138,0.3)] border border-white/10 h-[500px]">
            <img 
              src="https://images.unsplash.com/photo-1599488615731-7e5c2823528e?q=80&w=1000&auto=format&fit=crop" 
              alt="Lone Wolf in Winter" 
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0f172a] via-transparent to-transparent"></div>
            <div className="absolute bottom-8 left-0 right-0 text-center px-6">
                <Moon className="w-8 h-8 text-blue-300 mx-auto mb-2 opacity-80" />
                <p className="text-lg italic text-blue-100">"His howl was loud, but his heart was silent."</p>
            </div>
          </div>

          <div className="space-y-8 font-sans">
            <div className="bg-slate-800/50 p-8 rounded-2xl border border-slate-700 backdrop-blur-sm">
                <h3 className="text-2xl font-bold text-blue-300 mb-2">The Wolf Named Alex</h3>
                <div className="flex gap-2 mb-4">
                    <span className="bg-blue-900/50 text-blue-200 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">Age: 20 Moons</span>
                    <span className="bg-red-900/50 text-red-300 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">Condition: Hidden Winter</span>
                </div>
                
                <p className="text-lg leading-relaxed text-gray-300 mb-4">
                Alex was a young wolf who ran with the pack every day. To his mother and the elders, his coat shone bright. He hunted, he played, he led the way.
                </p>
                <p className="text-lg leading-relaxed text-gray-300">
                But when the pack slept, Alex lay awake, feeling a cold winter in his bones that no sun could warm. He did not speak of it, fearing he would be seen as weak.
                </p>
            </div>

            <div className="border-l-4 border-red-400 pl-6 py-2">
              <h4 className="text-xl font-bold text-white mb-2">The Silent Crisis</h4>
              <p className="text-gray-400">
                In the human world, we call this <strong>High-Functioning Depression</strong>. 
                Like the wolf who hunts while wounded, people can smile, work, and study while suffering a "Silent Winter" inside.
              </p>
            </div>
            
            <div className="bg-indigo-900/30 p-6 rounded-xl border border-indigo-500/30 flex items-start gap-4">
              <div className="text-4xl">🔮</div>
              <div>
                  <p className="font-semibold text-indigo-200 italic mb-2">
                    "I saw him running with the pack just yesterday. He looked strong."
                  </p>
                  <p className="text-sm text-gray-400">
                    - The Pack Mother (Alex's Mom)
                  </p>
              </div>
            </div>

            <button 
              onClick={onNext}
              className="w-full py-4 bg-gradient-to-r from-blue-600 to-indigo-700 hover:from-blue-500 hover:to-indigo-600 text-white rounded-xl font-bold transition shadow-lg shadow-blue-900/20 flex items-center justify-center gap-2"
            >
              View The Forest Records <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AlexStory;