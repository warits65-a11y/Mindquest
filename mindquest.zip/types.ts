export interface StoryScene {
  id: number;
  title: string;
  videoPlaceholderUrl: string; // URL for the "video" frame
  description: string; // Voiceover text
  question: string;
  section: '2Q' | '9Q' | '8Q';
  options: {
    label: string;
    score: number;
    feedback: string;
  }[];
}

export interface AssessmentResult {
  score: number; // Total weighted score or 9Q score
  phq2Score: number;
  phq9Score: number;
  suicideScore: number;
  persona: 'Lion' | 'Wolf' | 'Owl' | 'Dolphin';
  riskLevel: 'Low' | 'Moderate' | 'High';
  description: string;
  recommendation: string;
}

export type ViewState = 'home' | 'alex-story' | 'stats' | 'assessment' | 'results' | 'help';