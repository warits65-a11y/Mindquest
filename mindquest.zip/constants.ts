import { StoryScene } from './types';

export const STORY_SCENES: StoryScene[] = [
  // ==========================================
  // SECTION 1: 2Q (Screening)
  // Logic: If Score > 0 -> Proceed to 9Q
  // ==========================================
  {
    id: 1,
    title: "The Sleeping Lion",
    videoPlaceholderUrl: "https://images.unsplash.com/photo-1546182990-dffeafbe841d?auto=format&fit=crop&w=1600&q=80",
    description: "You used to lead the pride with a mighty roar. Now, you lie in the tall grass, watching the gazelles pass by without a care.",
    question: "Do you feel like a lion who has lost interest in the hunt and the joy of the savannah?",
    section: '2Q',
    options: [
      { label: "No, I am eager to hunt.", score: 0, feedback: "Normal" },
      { label: "Yes, I have lost my roar.", score: 1, feedback: "Risk" }
    ]
  },
  {
    id: 2,
    title: "The Rain-Soaked Wolf",
    videoPlaceholderUrl: "https://images.unsplash.com/photo-1474511320723-9a56873867b5?auto=format&fit=crop&w=1600&q=80",
    description: "A storm has soaked your fur. Even when the sun comes out, you feel heavy, cold, and gray inside.",
    question: "Do you feel down, depressed, or hopeless, like a wolf trapped in an endless storm?",
    section: '2Q',
    options: [
      { label: "No, I see the sun.", score: 0, feedback: "Normal" },
      { label: "Yes, the storm is heavy.", score: 1, feedback: "Risk" }
    ]
  },

  // ==========================================
  // SECTION 2: 9Q (Depression Severity)
  // Logic: If Score >= 7 -> Proceed to 8Q
  // ==========================================
  {
    id: 3,
    title: "The Lonely Monkey",
    videoPlaceholderUrl: "https://images.unsplash.com/photo-1540573133985-87b6da6dce60?auto=format&fit=crop&w=1600&q=80",
    description: "The troop is swinging from the vines, laughing and playing. You sit on a branch alone, not wanting to join in.",
    question: "Do you have little interest or pleasure in doing things you usually enjoy?",
    section: '9Q',
    options: [
      { label: "Not at all", score: 0, feedback: "None" },
      { label: "Several days", score: 1, feedback: "Mild" },
      { label: "More than half the days", score: 2, feedback: "Frequent" },
      { label: "Nearly every day", score: 3, feedback: "Daily" }
    ]
  },
  {
    id: 4,
    title: "The Heavy Elephant",
    videoPlaceholderUrl: "https://images.unsplash.com/photo-1557050543-4d5f4e07ef46?auto=format&fit=crop&w=1600&q=80",
    description: "You walk with the herd, but your steps are slow. It feels like you are carrying the weight of the entire jungle.",
    question: "Do you feel down, depressed, or hopeless?",
    section: '9Q',
    options: [
      { label: "Not at all", score: 0, feedback: "None" },
      { label: "Several days", score: 1, feedback: "Mild" },
      { label: "More than half the days", score: 2, feedback: "Frequent" },
      { label: "Nearly every day", score: 3, feedback: "Daily" }
    ]
  },
  {
    id: 5,
    title: "The Wide-Eyed Owl",
    videoPlaceholderUrl: "https://images.unsplash.com/photo-1579370966779-37332e18538b?auto=format&fit=crop&w=1600&q=80",
    description: "The forest is asleep, but your eyes are wide open staring at the moon. Or perhaps, you cannot wake up when the sun rises.",
    question: "Trouble falling or staying asleep, or sleeping too much?",
    section: '9Q',
    options: [
      { label: "Not at all", score: 0, feedback: "None" },
      { label: "Several days", score: 1, feedback: "Mild" },
      { label: "More than half the days", score: 2, feedback: "Frequent" },
      { label: "Nearly every day", score: 3, feedback: "Daily" }
    ]
  },
  {
    id: 6,
    title: "The Tired Sloth",
    videoPlaceholderUrl: "https://images.unsplash.com/photo-1568249080775-680373c09199?auto=format&fit=crop&w=1600&q=80",
    description: "Reaching for the next branch feels impossible. Your limbs are heavy, and you have no energy to move.",
    question: "Feeling tired or having little energy?",
    section: '9Q',
    options: [
      { label: "Not at all", score: 0, feedback: "None" },
      { label: "Several days", score: 1, feedback: "Mild" },
      { label: "More than half the days", score: 2, feedback: "Frequent" },
      { label: "Nearly every day", score: 3, feedback: "Daily" }
    ]
  },
  {
    id: 7,
    title: "The Panda's Bamboo",
    videoPlaceholderUrl: "https://images.unsplash.com/photo-1564349683136-77e08dbae63c?auto=format&fit=crop&w=1600&q=80",
    description: "The bamboo is fresh, but you turn away. Or perhaps, you keep eating long after you are full.",
    question: "Poor appetite or overeating?",
    section: '9Q',
    options: [
      { label: "Not at all", score: 0, feedback: "None" },
      { label: "Several days", score: 1, feedback: "Mild" },
      { label: "More than half the days", score: 2, feedback: "Frequent" },
      { label: "Nearly every day", score: 3, feedback: "Daily" }
    ]
  },
  {
    id: 8,
    title: "The Ashamed Wolf",
    videoPlaceholderUrl: "https://images.unsplash.com/photo-1504006833117-8886a355efbf?auto=format&fit=crop&w=1600&q=80",
    description: "You look at your reflection in the stream and feel like you don't belong in the pack anymore.",
    question: "Feeling bad about yourself — or that you are a failure or have let yourself or your family down?",
    section: '9Q',
    options: [
      { label: "Not at all", score: 0, feedback: "None" },
      { label: "Several days", score: 1, feedback: "Mild" },
      { label: "More than half the days", score: 2, feedback: "Frequent" },
      { label: "Nearly every day", score: 3, feedback: "Daily" }
    ]
  },
  {
    id: 9,
    title: "The Distracted Squirrel",
    videoPlaceholderUrl: "https://images.unsplash.com/photo-1507666405895-422eee4d517f?auto=format&fit=crop&w=1600&q=80",
    description: "You try to bury your acorn, but your mind jumps to a falling leaf, then a cloud. You cannot focus on the task.",
    question: "Trouble concentrating on things, such as reading the newspaper or watching television?",
    section: '9Q',
    options: [
      { label: "Not at all", score: 0, feedback: "None" },
      { label: "Several days", score: 1, feedback: "Mild" },
      { label: "More than half the days", score: 2, feedback: "Frequent" },
      { label: "Nearly every day", score: 3, feedback: "Daily" }
    ]
  },
  {
    id: 10,
    title: "The Pacing Tiger",
    videoPlaceholderUrl: "https://images.unsplash.com/photo-1508853189-36a8d8b47a67?auto=format&fit=crop&w=1600&q=80",
    description: "You are either pacing your cage restlessly, or moving as slowly as a turtle.",
    question: "Moving or speaking so slowly that other people could have noticed? Or the opposite — being so fidgety or restless that you have been moving around a lot more than usual?",
    section: '9Q',
    options: [
      { label: "Not at all", score: 0, feedback: "None" },
      { label: "Several days", score: 1, feedback: "Mild" },
      { label: "More than half the days", score: 2, feedback: "Frequent" },
      { label: "Nearly every day", score: 3, feedback: "Daily" }
    ]
  },
  {
    id: 11,
    title: "The Falling Eagle",
    videoPlaceholderUrl: "https://images.unsplash.com/photo-1611003228941-98852ba62227?auto=format&fit=crop&w=1600&q=80",
    description: "You fly high, but sometimes you look at the ground and wonder if it would be better to just fall.",
    question: "Thoughts that you would be better off dead, or of hurting yourself in some way?",
    section: '9Q',
    options: [
      { label: "Not at all", score: 0, feedback: "None" },
      { label: "Several days", score: 1, feedback: "Mild" },
      { label: "More than half the days", score: 2, feedback: "Frequent" },
      { label: "Nearly every day", score: 3, feedback: "Daily" }
    ]
  },

  // ==========================================
  // SECTION 3: 8Q (Suicide Risk)
  // Logic: Only shown if 9Q score >= 7
  // ==========================================
  {
    id: 12,
    title: "The Deep Whale",
    videoPlaceholderUrl: "https://images.unsplash.com/photo-1566310222384-78368868953f?auto=format&fit=crop&w=1600&q=80",
    description: "The ocean is deep and dark. In the past month, have you wished you could stay down there forever?",
    question: "In the past month, have you thought it would be better to be dead?",
    section: '8Q',
    options: [
      { label: "No", score: 0, feedback: "No" },
      { label: "Yes", score: 1, feedback: "Yes" }
    ]
  },
  {
    id: 13,
    title: "The Porcupine's Quill",
    videoPlaceholderUrl: "https://images.unsplash.com/photo-1552097327-0466e3fb242d?auto=format&fit=crop&w=1600&q=80",
    description: "Have you felt an urge to feel the sharp pain of the quills on your own skin?",
    question: "Have you wanted to hurt yourself or cause yourself pain?",
    section: '8Q',
    options: [
      { label: "No", score: 0, feedback: "No" },
      { label: "Yes", score: 2, feedback: "Yes" }
    ]
  },
  {
    id: 14,
    title: "The Cliff Goat",
    videoPlaceholderUrl: "https://images.unsplash.com/photo-1522002341999-52c7104a3901?auto=format&fit=crop&w=1600&q=80",
    description: "Standing on the edge of the mountain, did you think about jumping off?",
    question: "Have you actually thought about ending your own life?",
    section: '8Q',
    options: [
      { label: "No", score: 0, feedback: "No" },
      { label: "Yes", score: 6, feedback: "Yes" }
    ]
  },
  {
    id: 15,
    title: "The Spider's Web",
    videoPlaceholderUrl: "https://images.unsplash.com/photo-1587402092301-725e37c70fd8?auto=format&fit=crop&w=1600&q=80",
    description: "Have you woven a plan, like a spider weaves a web, for how you would end your journey?",
    question: "Do you have a specific plan to take your own life?",
    section: '8Q',
    options: [
      { label: "No", score: 0, feedback: "No" },
      { label: "Yes", score: 8, feedback: "Yes" }
    ]
  },
  {
    id: 16,
    title: "The Gathering Raven",
    videoPlaceholderUrl: "https://images.unsplash.com/photo-1522501783063-8a7e4b998246?auto=format&fit=crop&w=1600&q=80",
    description: "Have you collected things in your nest that you intend to use to end your life?",
    question: "Have you prepared anything to use for ending your life?",
    section: '8Q',
    options: [
      { label: "No", score: 0, feedback: "No" },
      { label: "Yes", score: 9, feedback: "Yes" }
    ]
  },
  {
    id: 17,
    title: "The Charging Bull",
    videoPlaceholderUrl: "https://images.unsplash.com/photo-1519985956038-f9b4221a4f00?auto=format&fit=crop&w=1600&q=80",
    description: "Have you run towards danger recently, hoping it would end everything?",
    question: "Have you recently tried to hurt yourself with intent to die?",
    section: '8Q',
    options: [
      { label: "No", score: 0, feedback: "No" },
      { label: "Yes", score: 4, feedback: "Yes" }
    ]
  },
  {
    id: 18,
    title: "The Phoenix",
    videoPlaceholderUrl: "https://images.unsplash.com/photo-1506543730435-e2c1d455b510?auto=format&fit=crop&w=1600&q=80",
    description: "In the past, did you try to burn everything down and leave this world, expecting never to return?",
    question: "Have you ever attempted suicide expecting it to be fatal?",
    section: '8Q',
    options: [
      { label: "No", score: 0, feedback: "No" },
      { label: "Yes", score: 10, feedback: "Yes" }
    ]
  },
  {
    id: 19,
    title: "The Scarred Bear",
    videoPlaceholderUrl: "https://images.unsplash.com/photo-1575550959106-5a7defe28b56?auto=format&fit=crop&w=1600&q=80",
    description: "Do you carry the battle scars of a past attempt to end your own life?",
    question: "Have you had a history of attempting suicide in the past?",
    section: '8Q',
    options: [
      { label: "No", score: 0, feedback: "No" },
      { label: "Yes", score: 4, feedback: "Yes" }
    ]
  }
];

export const DEPRESSION_STATS = [
  { year: '2558', patients: 231082 },
  { year: '2559', patients: 250000 },
  { year: '2560', patients: 240000 },
  { year: '2561', patients: 300000 },
  { year: '2562', patients: 290000 },
  { year: '2563', patients: 350000 },
  { year: '2564', patients: 345000 },
  { year: '2565', patients: 360000 },
  { year: '2566', patients: 399645 },
];