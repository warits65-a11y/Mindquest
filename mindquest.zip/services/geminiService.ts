import { GoogleGenAI } from "@google/genai";
import { AssessmentResult } from "../types";

const API_KEY = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey: API_KEY });

export const generatePersonalizedAdvice = async (result: AssessmentResult): Promise<string> => {
  if (!API_KEY) {
    return "I'm glad you took this step to check in on yourself. Based on your results, it might be a good idea to chat with someone you trust or try some relaxing activities. You're doing great just by being aware of your feelings.";
  }

  try {
    const prompt = `
      You are a supportive and friendly AI assistant for MindQuest, helping people understand their mental well-being through a gentle lens.
      
      Assessment Data:
      - Animal Archetype: ${result.persona}
      - Risk Level: ${result.riskLevel}
      - Score: ${result.score}/12
      
      Task:
      Write a warm, supportive message offering gentle advice and suggestions (max 100 words).
      
      Guidelines:
      1. Tone: Friendly, encouraging, and informal. Like a helpful friend or a supportive guide.
      2. No Jargon: Do not use any medical or clinical terms. Use simple, everyday language.
      3. Nature of Advice: Present the information as "suggestions" or "next steps" to try, rather than a final medical diagnosis. 
      4. Message: Focus on self-care, mindfulness, and the importance of checking in with others.
      5. Risk Context: 
         - For Low risk: Congratulate them on their balance and suggest ways to maintain it.
         - For Moderate/High risk: Gently suggest that talking to a professional or a trusted adult is a brave and helpful step to take when things feel a bit heavy.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });

    return response.text || "Thank you for sharing your journey today. Remember that these results are just a guide to help you understand your feelings. It's always a good idea to reach out to people who care about you.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "It looks like I'm having a little trouble connecting. Please know that your feelings are important, and reaching out to someone you trust is a wonderful way to take care of yourself.";
  }
};