import React from 'react';
import { ArrowLeft, MapPin, Phone } from 'lucide-react';

interface NearbyHelpProps {
  onBack: () => void;
}

const NearbyHelp: React.FC<NearbyHelpProps> = ({ onBack }) => {
  // Mock data for demo purposes
  const clinics = [
    { name: "MindWell Clinic", distance: "0.8 km", rating: 4.8 },
    { name: "City Mental Health Center", distance: "2.1 km", rating: 4.5 },
    { name: "Dr. Somsak Psychiatry", distance: "3.5 km", rating: 4.9 },
  ];

  return (
    <div className="min-h-screen bg-white p-6 md:p-12">
       <button onClick={onBack} className="flex items-center gap-2 text-mq-dark font-bold mb-8 hover:opacity-75">
        <ArrowLeft className="w-5 h-5" /> Back
      </button>

      <div className="max-w-3xl mx-auto">
         <h2 className="text-3xl font-extrabold text-mq-dark mb-2 text-center">Nearby Help</h2>
         <p className="text-center text-gray-500 mb-8">Connect with professionals near you immediately.</p>

         {/* Mock Map Visual */}
         <div className="w-full h-64 bg-slate-200 rounded-2xl mb-8 relative overflow-hidden flex items-center justify-center border-4 border-white shadow-lg">
             <div className="absolute inset-0 opacity-20" style={{backgroundImage: 'radial-gradient(circle, #000 1px, transparent 1px)', backgroundSize: '20px 20px'}}></div>
             <div className="bg-blue-500 text-white p-3 rounded-full shadow-xl z-10 animate-bounce">
                <MapPin className="w-8 h-8" />
             </div>
             <span className="absolute bottom-4 right-4 text-xs text-gray-500 bg-white/80 px-2 rounded">Mock Map View</span>
         </div>

         <div className="space-y-4">
            {clinics.map((clinic, idx) => (
                <div key={idx} className="flex items-center justify-between p-5 bg-white border border-gray-100 rounded-xl shadow-sm hover:shadow-md transition">
                    <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center text-green-600">
                             <MapPin className="w-6 h-6" />
                        </div>
                        <div>
                            <h4 className="font-bold text-lg text-slate-800">{clinic.name}</h4>
                            <p className="text-sm text-gray-500">{clinic.distance} • ⭐ {clinic.rating}</p>
                        </div>
                    </div>
                    <button className="bg-mq-dark text-white px-4 py-2 rounded-lg font-semibold text-sm flex items-center gap-2 hover:bg-slate-800">
                        <Phone className="w-4 h-4" /> Call
                    </button>
                </div>
            ))}
         </div>
         
         <div className="mt-8 p-6 bg-yellow-50 rounded-xl text-center">
            <p className="text-yellow-800 font-medium text-sm">
                Showing results based on generic location. In a real app, this would use your precise GPS coordinates.
            </p>
         </div>
      </div>
    </div>
  );
};

export default NearbyHelp;