import React from 'react';
import { ArrowRight, PlayCircle, Sparkles } from 'lucide-react';
import { ViewState } from '../types';

interface HeroProps {
  onNavigate: (view: ViewState) => void;
}

const Hero: React.FC<HeroProps> = ({ onNavigate }) => {
  return (
    <div className="relative min-h-screen text-white overflow-hidden flex flex-col items-center justify-center">
      {/* Immersive Forest Background */}
      <div className="absolute inset-0 z-0">
        <img 
            src="https://images.unsplash.com/photo-1511497584788-876760111969?q=80&w=2000&auto=format&fit=crop" 
            alt="Mystical Forest" 
            className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-indigo-900/70 via-indigo-900/50 to-black/80"></div>
      </div>

      <nav className="absolute top-0 w-full p-6 flex justify-between items-center z-20">
        <div className="text-2xl font-bold flex items-center gap-2 drop-shadow-lg">
           <div className="w-10 h-10 bg-mq-yellow rounded-full flex items-center justify-center text-mq-dark shadow-[0_0_15px_rgba(250,204,21,0.6)]">
             <Sparkles className="w-6 h-6" />
           </div>
           <span className="font-serif tracking-wide">MindQuest</span>
        </div>
        <div className="hidden md:flex gap-6 text-sm font-semibold text-gray-200">
          <button onClick={() => onNavigate('alex-story')} className="hover:text-mq-yellow transition drop-shadow-md">The Wolf's Tale</button>
          <button onClick={() => onNavigate('stats')} className="hover:text-mq-yellow transition drop-shadow-md">Forest Records</button>
          <button onClick={() => onNavigate('help')} className="hover:text-mq-yellow transition drop-shadow-md">Healer's Hut</button>
        </div>
      </nav>

      <div className="container mx-auto px-6 z-20 text-center flex flex-col items-center">
        <div className="mb-8 relative group cursor-pointer" onClick={() => onNavigate('assessment')}>
           {/* Animated Spirit Animal Glow */}
           <div className="absolute inset-0 bg-mq-yellow rounded-full opacity-20 blur-xl group-hover:opacity-40 transition-opacity duration-1000 animate-pulse"></div>
           <div className="w-48 h-48 md:w-56 md:h-56 rounded-full p-1 mx-auto relative overflow-hidden border-4 border-white/30 backdrop-blur-sm shadow-2xl transition transform group-hover:scale-105">
             <img 
               src="https://images.unsplash.com/photo-1546182990-dffeafbe841d?q=80&w=1000&auto=format&fit=crop" 
               alt="Spirit Lion" 
               className="w-full h-full object-cover rounded-full"
             />
           </div>
           <div className="absolute -bottom-2 w-full text-center">
             <span className="bg-indigo-900/80 text-mq-yellow px-4 py-1 rounded-full text-xs font-bold shadow-lg backdrop-blur-md border border-white/10 uppercase tracking-widest">
               Your Spirit Guide
             </span>
           </div>
        </div>

        <h1 className="text-5xl md:text-7xl font-extrabold mb-4 tracking-tight font-serif drop-shadow-2xl">
          Discover Your <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-mq-yellow to-orange-400">Spirit Animal</span>
        </h1>
        
        <p className="text-xl md:text-2xl font-light text-gray-200 mb-10 max-w-xl mx-auto leading-relaxed drop-shadow-md">
          Journey through the Forest of Minds. <br/>
          Uncover the hidden strengths and silent shadows within you.
        </p>

        <div className="flex flex-col md:flex-row gap-5">
          <button 
            onClick={() => onNavigate('assessment')}
            className="group bg-mq-yellow text-mq-dark px-10 py-4 rounded-full font-bold text-lg hover:bg-white transition-all transform hover:scale-105 shadow-[0_0_20px_rgba(250,204,21,0.4)] flex items-center gap-3"
          >
            <PlayCircle className="w-6 h-6" />
            Begin the Ritual
          </button>
          
          <button 
            onClick={() => onNavigate('alex-story')}
            className="px-8 py-4 rounded-full font-semibold text-white border border-white/30 hover:bg-white/10 backdrop-blur-md transition-all flex items-center gap-2"
          >
            Read the Legend <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="absolute bottom-6 text-xs text-gray-400 opacity-60">
        AI Generated Experience • Guided by Professionals
      </div>
    </div>
  );
};

export default Hero;