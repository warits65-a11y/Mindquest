import React from 'react';
import { AssessmentResult } from '../types';

interface MedicalReportProps {
  result: AssessmentResult;
  advice: string;
  onClose: () => void;
}

const MedicalReport: React.FC<MedicalReportProps> = ({ result, advice, onClose }) => {
  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 overflow-y-auto print:p-0 print:bg-white print:static print:block backdrop-blur-sm">
       <div id="medical-report-content" className="bg-white p-8 max-w-3xl w-full rounded-xl shadow-2xl print:shadow-none print:w-full print:max-w-none print:p-0 print:rounded-none">
          
          {/* Header Actions - Hidden when printing */}
          <div className="flex justify-between items-center mb-8 print:hidden">
             <h2 className="text-2xl font-bold text-gray-800">Results Form Preview</h2>
             <div className="flex gap-4">
                 <button 
                   onClick={() => window.print()} 
                   className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg font-bold transition flex items-center gap-2"
                 >
                   🖨️ Print Form
                 </button>
                 <button 
                   onClick={onClose} 
                   className="bg-gray-200 hover:bg-gray-300 text-gray-800 px-6 py-2 rounded-lg transition"
                 >
                   Close
                 </button>
             </div>
          </div>

          {/* The Formal Clinical Report */}
          <div className="border-[3px] border-gray-900 p-8 relative min-h-[800px]">
              
              {/* Header */}
              <div className="flex justify-between items-start border-b-[3px] border-gray-900 pb-6 mb-8">
                  <div>
                      <h1 className="text-3xl font-black uppercase tracking-widest text-gray-900">Medical Assessment Report</h1>
                      <p className="text-gray-600 font-serif italic mt-1 text-lg">แบบประเมินโรคซึมเศร้า (Depression Screening Form)</p>
                  </div>
                  <div className="text-right">
                      <div className="bg-gray-900 text-white px-4 py-1 font-bold inline-block text-sm tracking-wider mb-2">CONFIDENTIAL</div>
                      <p className="text-sm font-medium">Ref: MQ-{Math.floor(Math.random() * 10000)}</p>
                      <p className="text-sm font-medium">Date: {new Date().toLocaleDateString()}</p>
                  </div>
              </div>

              {/* Patient Info Inputs (Empty for printing) */}
              <div className="grid grid-cols-2 gap-x-12 gap-y-8 mb-10 text-sm">
                  <div className="flex items-end gap-2 border-b border-gray-400 pb-1">
                      <span className="font-bold text-gray-900 w-16">Name:</span>
                      <span className="flex-1"></span>
                  </div>
                  <div className="flex items-end gap-2 border-b border-gray-400 pb-1">
                      <span className="font-bold text-gray-900 w-12">Age:</span>
                      <span className="flex-1"></span>
                  </div>
                  <div className="flex items-end gap-2 border-b border-gray-400 pb-1">
                      <span className="font-bold text-gray-900 w-16">ID Card:</span>
                      <span className="flex-1"></span>
                  </div>
                   <div className="flex items-end gap-2 border-b border-gray-400 pb-1">
                      <span className="font-bold text-gray-900 w-20">Contact:</span>
                      <span className="flex-1"></span>
                  </div>
              </div>

              {/* Clinical Results Section */}
              <div className="mb-10">
                  <h3 className="font-bold text-lg mb-4 uppercase flex items-center gap-2">
                    <span className="w-2 h-6 bg-gray-900 block"></span>
                    Clinical Screening Results
                  </h3>
                  <table className="w-full border-collapse border border-gray-900 text-sm">
                      <thead className="bg-gray-100">
                          <tr>
                              <th className="border border-gray-900 p-3 text-left w-1/3">Assessment Tool</th>
                              <th className="border border-gray-900 p-3 text-center w-1/6">Score</th>
                              <th className="border border-gray-900 p-3 text-left w-1/4">Interpretation</th>
                              <th className="border border-gray-900 p-3 text-left">Clinical Indicator</th>
                          </tr>
                      </thead>
                      <tbody>
                          <tr>
                              <td className="border border-gray-900 p-3 font-semibold">MindQuest Narrative (2Q/9Q Correlated)</td>
                              <td className="border border-gray-900 p-3 text-center font-bold text-xl">{result.score}/12</td>
                              <td className="border border-gray-900 p-3">
                                  <span className={`font-bold px-2 py-1 rounded ${result.riskLevel === 'High' ? 'bg-red-100 text-red-800' : result.riskLevel === 'Moderate' ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800'}`}>
                                    {result.riskLevel.toUpperCase()} RISK
                                  </span>
                              </td>
                              <td className="border border-gray-900 p-3 italic text-gray-600">{result.persona} Archetype</td>
                          </tr>
                      </tbody>
                  </table>
                  
                  {/* Score Reference Grid */}
                  <div className="mt-4 grid grid-cols-4 text-xs text-center border border-gray-300">
                      <div className="p-2 border-r border-gray-300 bg-green-50">0-2: Normal</div>
                      <div className="p-2 border-r border-gray-300 bg-yellow-50">3-5: Mild</div>
                      <div className="p-2 border-r border-gray-300 bg-orange-50">6-8: Moderate</div>
                      <div className="p-2 bg-red-50">9+: Severe</div>
                  </div>
              </div>

               {/* Professional Advice Section */}
              <div className="mb-12">
                   <h3 className="font-bold text-lg mb-4 uppercase flex items-center gap-2">
                      <span className="w-2 h-6 bg-gray-900 block"></span>
                      Professional Medical Advice
                   </h3>
                   <div className="border border-gray-300 p-6 bg-gray-50 text-gray-800 text-sm leading-relaxed whitespace-pre-line font-medium">
                       {advice}
                   </div>
              </div>

               {/* Footer / Signatures */}
               <div className="absolute bottom-8 left-8 right-8">
                   <div className="grid grid-cols-2 gap-16">
                       <div className="text-center">
                           <div className="border-b border-gray-900 h-8 mb-3"></div>
                           <p className="text-sm font-bold text-gray-600">Patient Signature</p>
                       </div>
                       <div className="text-center">
                           <div className="border-b border-gray-900 h-8 mb-3"></div>
                           <p className="text-sm font-bold text-gray-600">Physician / Screener Signature</p>
                       </div>
                   </div>
                   
                   <div className="mt-8 pt-4 border-t border-gray-200 text-[10px] text-gray-400 flex justify-between">
                       <span>Generated by MindQuest Platform</span>
                       <span>Clinical Support Tool v1.0</span>
                   </div>
               </div>
          </div>
       </div>
    </div>
  );
};

export default MedicalReport;