import React from 'react';
import { ArrowLeft, ArrowRight, TrendingUp, Feather } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { DEPRESSION_STATS } from '../constants';

interface StatsProps {
  onBack: () => void;
  onNext: () => void;
}

const Stats: React.FC<StatsProps> = ({ onBack, onNext }) => {
  return (
    <div className="min-h-screen bg-[#f0fdf4] text-slate-800 p-6 md:p-12 relative">
       {/* Background pattern */}
       <div className="absolute inset-0 opacity-5 pointer-events-none" style={{backgroundImage: 'url("https://www.transparenttextures.com/patterns/leaf.png")'}}></div>

      <button onClick={onBack} className="relative z-10 flex items-center gap-2 text-green-800 font-bold mb-8 hover:opacity-75">
        <ArrowLeft className="w-5 h-5" /> Return to Story
      </button>

      <div className="max-w-5xl mx-auto relative z-10">
        <div className="text-center mb-8">
            <h2 className="text-3xl md:text-5xl font-extrabold text-green-900 mb-2 font-serif flex items-center justify-center gap-3">
                <Feather className="w-8 h-8 md:w-10 md:h-10 text-green-600" />
                Forest Records
            </h2>
            <p className="text-green-700 font-medium">Tracking the Shadows (Depression Rates)</p>
        </div>
        
        <div className="bg-white/80 backdrop-blur-sm p-6 md:p-10 rounded-3xl shadow-xl shadow-green-900/5 mb-12 border border-green-100">
           <div className="flex flex-col md:flex-row justify-between items-end mb-8 gap-4">
              <div className="bg-yellow-100 text-yellow-800 font-bold py-2 px-4 rounded-lg shadow-sm border border-yellow-200">
                 Year 2558: 231,082 Souls
              </div>
              <div className="text-right">
                 <p className="text-5xl font-extrabold text-green-800">399,645</p>
                 <p className="text-sm font-bold text-orange-600 flex items-center justify-end gap-1 uppercase tracking-wider mt-1">
                   <TrendingUp className="w-4 h-4" /> Increasing Shadows
                 </p>
              </div>
           </div>
           
           <div className="h-[300px] w-full">
             <ResponsiveContainer width="100%" height="100%">
               <LineChart data={DEPRESSION_STATS}>
                 <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#dcfce7" />
                 <XAxis dataKey="year" axisLine={false} tickLine={false} tick={{fill: '#166534', fontSize: 12}} dy={10} />
                 <YAxis hide domain={['dataMin - 10000', 'dataMax + 10000']} />
                 <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: '1px solid #bbf7d0', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.05)', backgroundColor: 'rgba(255, 255, 255, 0.95)' }}
                    itemStyle={{ color: '#166534', fontWeight: 'bold' }}
                 />
                 <Line 
                    type="monotone" 
                    dataKey="patients" 
                    stroke="#16a34a" 
                    strokeWidth={4} 
                    dot={{ r: 5, fill: '#15803d', strokeWidth: 2, stroke: '#f0fdf4' }} 
                    activeDot={{ r: 8, fill: '#16a34a' }}
                 />
               </LineChart>
             </ResponsiveContainer>
           </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
           <div className="bg-white p-8 rounded-2xl shadow-lg border-l-8 border-green-500">
              <h3 className="text-xl font-bold mb-2 text-green-900">The Power of Knowing</h3>
              <p className="text-3xl font-bold text-green-600 mb-2">+1.2%</p>
              <p className="text-gray-500">More animals are finding their way out of the dark (Diagnosis rate).</p>
           </div>
           <div className="bg-white p-8 rounded-2xl shadow-lg border-l-8 border-blue-500">
              <h3 className="text-xl font-bold mb-2 text-blue-900">Healing Speed</h3>
              <p className="text-3xl font-bold text-blue-600 mb-2">69% Recover</p>
              <p className="text-gray-500">When the pack supports them early (Treatment within 90 days).</p>
           </div>
        </div>

        <div className="mt-12 text-center">
          <p className="text-lg text-green-800 mb-6 font-medium italic">
            "The forest is vast, but no one has to walk it alone."
          </p>
          <button 
            onClick={onNext}
            className="bg-green-700 text-white px-10 py-4 rounded-full font-bold text-xl hover:bg-green-800 transition shadow-xl shadow-green-700/30 flex items-center gap-2 mx-auto transform hover:-translate-y-1"
          >
            Start Your Spirit Journey <ArrowRight className="w-6 h-6" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default Stats;