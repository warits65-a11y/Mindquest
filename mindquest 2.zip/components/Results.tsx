import React, { useEffect, useState } from 'react';
import { AssessmentResult } from '../types';
import { generatePersonalizedAdvice } from '../services/geminiService';
import { Heart, MapPin, Phone, Printer, RefreshCcw, Stethoscope } from 'lucide-react';
import MedicalReport from './MedicalReport';

interface ResultsProps {
  result: AssessmentResult;
  onRestart: () => void;
  onFindHelp: () => void;
}

const Results: React.FC<ResultsProps> = ({ result, onRestart, onFindHelp }) => {
  const [aiAdvice, setAiAdvice] = useState<string>('Analyzing clinical data...');
  const [showReport, setShowReport] = useState(false);

  useEffect(() => {
    generatePersonalizedAdvice(result).then(setAiAdvice);
  }, [result]);

  const isHighRisk = result.riskLevel === 'High';

  const getAvatarStyle = (risk: string) => {
    switch (risk) {
      case 'Low':
        // Vibrant, confident - gentle bounce and glow
        return "scale-110 drop-shadow-[0_0_15px_rgba(250,204,21,0.5)] animate-[bounce_2s_infinite] brightness-110 saturate-125";
      case 'Moderate':
        // Thoughtful - gentle pulse/sway
        return "animate-[pulse_4s_ease-in-out_infinite]";
      case 'High':
        // Subdued, distressed - grayscale, smaller, slow breath
        return "grayscale-[0.8] brightness-90 scale-90 blur-[0.5px] animate-[pulse_6s_ease-in-out_infinite]";
      default:
        return "";
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 py-12 px-4 print:hidden">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
           <h2 className="text-4xl font-extrabold text-mq-dark mb-2">Your MindQuest Results</h2>
           <p className="text-gray-500">Assessment Complete</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
            {/* Persona Card */}
            <div className={`relative bg-white rounded-3xl p-8 shadow-xl text-center overflow-hidden border-t-8 ${isHighRisk ? 'border-red-400' : 'border-green-400'}`}>
                <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-indigo-50 to-transparent"></div>
                
                <div className="relative z-10">
                    <div className="w-40 h-40 mx-auto bg-indigo-100 rounded-full mb-6 flex items-center justify-center">
                        <div className={`text-6xl transition-all duration-1000 transform ${getAvatarStyle(result.riskLevel)}`}>
                          {result.persona === 'Lion' ? '🦁' : result.persona === 'Wolf' ? '🐺' : result.persona === 'Dolphin' ? '🐬' : '🦉'}
                        </div>
                    </div>
                    
                    <h3 className="text-3xl font-bold text-slate-800 mb-2">You are a {result.persona}!</h3>
                    <div className={`inline-block px-4 py-1 rounded-full text-sm font-bold mb-4 ${isHighRisk ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'}`}>
                        Risk Level: {result.riskLevel}
                    </div>
                    <p className="text-slate-600 italic">"{result.description}"</p>
                </div>
            </div>

            {/* Guidance Card - Updated to Professional Advice */}
            <div className="bg-white rounded-3xl p-8 shadow-xl flex flex-col justify-between">
                <div>
                    <div className="flex items-center gap-2 mb-4">
                        <Stethoscope className="text-blue-600 w-6 h-6" />
                        <h3 className="text-xl font-bold text-mq-dark">Professional Medical Advice</h3>
                    </div>
                    <div className="bg-blue-50 p-6 rounded-xl border border-blue-100 text-slate-800 text-sm leading-relaxed min-h-[160px] font-medium whitespace-pre-line">
                        {aiAdvice}
                    </div>
                </div>

                {isHighRisk && (
                    <div className="mt-6 bg-red-50 p-4 rounded-xl flex items-start gap-3 border border-red-100 animate-pulse">
                        <div className="bg-red-500 text-white rounded-full p-1 mt-1">
                           <Phone className="w-4 h-4" />
                        </div>
                        <div>
                            <p className="text-red-700 font-bold text-sm">Clinical Warning: Severe Distress</p>
                            <p className="text-red-600 text-xs">Immediate professional consultation is strongly advised.</p>
                        </div>
                    </div>
                )}
            </div>
        </div>

        {/* Action Buttons */}
        <div className="grid md:grid-cols-2 gap-4">
             <button 
                onClick={onFindHelp}
                className="bg-mq-dark text-white p-4 rounded-xl font-bold text-lg hover:bg-slate-800 transition shadow-lg flex items-center justify-center gap-2"
             >
                <MapPin className="w-5 h-5" />
                Find Nearby Help
             </button>

             <button 
                onClick={() => setShowReport(true)}
                className="bg-white text-mq-dark border border-gray-200 p-4 rounded-xl font-bold text-lg hover:bg-gray-50 transition shadow-sm flex items-center justify-center gap-2 group"
             >
                <Printer className="w-5 h-5 group-hover:scale-110 transition" />
                Print Results Form
             </button>
        </div>

        <div className="text-center mt-12">
            <button onClick={onRestart} className="text-gray-400 hover:text-mq-dark flex items-center gap-2 mx-auto">
                <RefreshCcw className="w-4 h-4" /> Retake Assessment
            </button>
        </div>

        {/* Print Modal */}
        {showReport && (
            <MedicalReport 
                result={result} 
                advice={aiAdvice} 
                onClose={() => setShowReport(false)} 
            />
        )}
      </div>
    </div>
  );
};

export default Results;