export interface StoryScene {
  id: number;
  title: string;
  videoPlaceholderUrl: string; // URL for the "video" frame
  description: string; // Voiceover text
  question: string;
  options: {
    label: string;
    score: number; // 0 = healthy, 1 = mild, 2 = severe
    feedback: string;
  }[];
}

export interface AssessmentResult {
  score: number;
  persona: 'Lion' | 'Wolf' | 'Owl' | 'Dolphin';
  riskLevel: 'Low' | 'Moderate' | 'High';
  description: string;
  recommendation: string;
}

export type ViewState = 'home' | 'alex-story' | 'stats' | 'assessment' | 'results' | 'help';