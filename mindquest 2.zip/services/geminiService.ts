import { GoogleGenAI } from "@google/genai";
import { AssessmentResult } from "../types";

const API_KEY = process.env.API_KEY || ''; // Ensure this is set in your environment
const ai = new GoogleGenAI({ apiKey: API_KEY });

export const generatePersonalizedAdvice = async (result: AssessmentResult): Promise<string> => {
  if (!API_KEY) {
    return "Clinical analysis unavailable (Missing API Key). Based on the assessment score, we recommend speaking to a healthcare professional for a formal evaluation.";
  }

  try {
    const prompt = `
      You are a clinical AI assistant for the MindQuest mental health platform.
      
      User Assessment Data:
      - Screening Result Persona: ${result.persona}
      - Risk Level: ${result.riskLevel}
      - Score: ${result.score}/12 (Higher score indicates higher depression risk)
      
      Task:
      Generate a professional medical advice summary (max 100 words) to be printed on a clinical result form.
      
      Guidelines:
      1. Tone: Professional, objective, and clinically supportive. Avoid metaphorical language ("winter", "forest") in this output; use standard medical/counseling terminology.
      2. Observation: Briefly explain what the risk level suggests regarding potential depressive symptoms.
      3. Action Plan: Provide concrete next steps (e.g., "Consultation with a psychiatrist is recommended", "Monitor symptoms", "Self-care strategies").
      4. Urgency: If High Risk, strictly emphasize the necessity of professional intervention.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });

    return response.text || "Unable to generate clinical advice at this time.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Automated clinical report generation failed. Please consult a specialist based on the risk level indicated.";
  }
};