import { StoryScene } from './types';

export const STORY_SCENES: StoryScene[] = [
  {
    id: 1,
    title: "The Eagle's Flight",
    videoPlaceholderUrl: "https://images.unsplash.com/photo-1505560938361-229215037d40?q=80&w=1600&auto=format&fit=crop", // Eagle soaring
    description: "You are a majestic eagle taking flight from a high peak. The wind is blowing strongly today.",
    question: "How do your wings feel against the wind?",
    options: [
      { label: "Strong and light. I can soar effortlessly.", score: 0, feedback: "High energy." },
      { label: "A bit heavy. I have to flap hard to stay aloft.", score: 1, feedback: "Struggling with energy." },
      { label: "Exhausted. I can't lift them; I'm falling.", score: 3, feedback: "Depleted energy." }
    ]
  },
  {
    id: 2,
    title: "The Dolphin's Pod",
    videoPlaceholderUrl: "https://images.unsplash.com/photo-1570481662006-a3a1374699e8?q=80&w=1600&auto=format&fit=crop", // Dolphin underwater
    description: "You are swimming in the vast ocean. Your pod (friends and family) is swimming nearby.",
    question: "How connected do you feel to the pack?",
    options: [
      { label: "We move as one. I feel safe and loved.", score: 0, feedback: "Socially connected." },
      { label: "I'm there, but swimming feels like work.", score: 1, feedback: "Social withdrawal." },
      { label: "I'm drifting into the deep alone. They can't hear me.", score: 3, feedback: "Severe isolation." }
    ]
  },
  {
    id: 3,
    title: "The Tiger's Jungle",
    videoPlaceholderUrl: "https://images.unsplash.com/photo-1547406268-96c2105156a0?q=80&w=1600&auto=format&fit=crop", // Jungle Tiger
    description: "You are navigating the dense jungle at night. Shadows are everywhere.",
    question: "How does the world around you look right now?",
    options: [
      { label: "Vibrant and full of life. I am the hunter.", score: 0, feedback: "Positive outlook." },
      { label: "Grey and confusing. I keep losing the path.", score: 2, feedback: "Mental fog/Confusion." },
      { label: "Dark and threatening. I just want to hide.", score: 3, feedback: "Fear/Depression." }
    ]
  },
  {
    id: 4,
    title: "The Cat's Reflection",
    videoPlaceholderUrl: "https://images.unsplash.com/photo-1513245543132-31f507417b26?q=80&w=1600&auto=format&fit=crop", // Cat looking
    description: "You stop by a still pond to drink and see your reflection in the water.",
    question: "What spirit animal stares back at you?",
    options: [
      { label: "A confident Lion, ready to lead.", score: 0, feedback: "High self-esteem." },
      { label: "A small, tired kitten.", score: 1, feedback: "Low self-worth." },
      { label: "A ghost. I don't recognize myself.", score: 3, feedback: "Loss of identity." }
    ]
  }
];

export const DEPRESSION_STATS = [
  { year: '2558', patients: 231082 },
  { year: '2559', patients: 250000 },
  { year: '2560', patients: 240000 },
  { year: '2561', patients: 300000 },
  { year: '2562', patients: 290000 },
  { year: '2563', patients: 350000 },
  { year: '2564', patients: 345000 },
  { year: '2565', patients: 360000 },
  { year: '2566', patients: 399645 },
];