import React, { useState } from 'react';
import Hero from './components/Hero';
import Assessment from './components/Assessment';
import Results from './components/Results';
import Stats from './components/Stats';
import AlexStory from './components/AlexStory';
import NearbyHelp from './components/NearbyHelp';
import { ViewState, AssessmentResult } from './types';

const App: React.FC = () => {
  const [view, setView] = useState<ViewState>('home');
  const [result, setResult] = useState<AssessmentResult | null>(null);

  const handleAssessmentComplete = (res: AssessmentResult) => {
    setResult(res);
    setView('results');
  };

  const handleRestart = () => {
    setResult(null);
    setView('home');
  };

  return (
    <div className="font-sans">
      {view === 'home' && <Hero onNavigate={setView} />}
      
      {view === 'alex-story' && (
        <AlexStory 
          onBack={() => setView('home')} 
          onNext={() => setView('stats')} 
        />
      )}
      
      {view === 'stats' && (
        <Stats 
          onBack={() => setView('alex-story')} 
          onNext={() => setView('assessment')} 
        />
      )}
      
      {view === 'assessment' && (
        <Assessment onComplete={handleAssessmentComplete} />
      )}
      
      {view === 'results' && result && (
        <Results 
          result={result} 
          onRestart={handleRestart}
          onFindHelp={() => setView('help')}
        />
      )}
      
      {view === 'help' && (
        <NearbyHelp onBack={() => setView('home')} />
      )}
    </div>
  );
};

export default App;